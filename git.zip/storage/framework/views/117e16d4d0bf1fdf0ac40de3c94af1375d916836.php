<html>
    <head>
        <title>
        New user registered
        </title>
    </head>
    <body>
        <?php echo e($e_message); ?>

    </body>
</html>