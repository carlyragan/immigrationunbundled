<?php $__env->startSection('contents'); ?>

<?php echo $__env->make('temp1._inc.stepper', [
'stepper_selected' => '5',
'stepper_title' => 'Step 5: Book your schedule/Arrange your meeting'
], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="legal-team mt-3">
    <!-- Calendly inline widget begin -->
<div class="calendly-inline-widget" data-url="https://calendly.com/canadaimmigration" style="min-width:320px;height:580px;"></div>
<script type="text/javascript" src="https://assets.calendly.com/assets/external/widget.js"></script>
<!-- Calendly inline widget end -->
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>