<html>
    <head>
        <title>
        New user registered
        </title>
    </head>
    <body>
        {{$e_message}}
    </body>
</html>